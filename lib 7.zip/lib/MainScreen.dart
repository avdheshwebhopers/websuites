import 'package:flutter/material.dart';
import 'custom drawer.dart';

class MainScreen extends StatefulWidget {
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int selectedIndex = 0;
  bool isCollapsed = false;

  void onDrawerItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
    // No need to call Navigator.pop() here for tablet/desktop
  }

  void toggleDrawerCollapse() {
    setState(() {
      isCollapsed = !isCollapsed;
    });
  }

  @override
  Widget build(BuildContext context) {
    bool isTabletOrDesktop = MediaQuery.of(context).size.width >= 600;
    String title = ['Inbox', 'Sent', 'Drafts'][selectedIndex];

    return Scaffold(
      appBar: isTabletOrDesktop
          ? null
          : AppBar(
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
        title: Text(
          title,
          style: TextStyle(color: Colors.black, fontSize: 18),
        ),
      ),
      drawer: !isTabletOrDesktop
          ? Drawer(
        child: CustomDrawer(
          selectedIndex: selectedIndex,
          onItemSelected: onDrawerItemTapped,
          isCollapsed: isCollapsed,
          onCollapseToggle: toggleDrawerCollapse,
          isTabletOrDesktop: isTabletOrDesktop,
        ),
      )
          : null,
      body: Row(
        children: [
          // CustomDrawer only appears on tablet and desktop screens
          if (isTabletOrDesktop)
            CustomDrawer(
              selectedIndex: selectedIndex,
              onItemSelected: onDrawerItemTapped,
              isCollapsed: isCollapsed,
              onCollapseToggle: toggleDrawerCollapse,
              isTabletOrDesktop: isTabletOrDesktop,
            ),
          // Main content area
          Expanded(
            child: Container(
              color: Colors.grey[100],
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      title,
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Expanded(
                    child: Center(
                      child: Text(
                        'Content for $title',
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
