// import 'package:get/get.dart';
//
// class MainController extends GetxController {
//   var selectedIndex = 0.obs; // Observable variable
//   var isCollapsed = false.obs; // Observable variable for drawer state
//
//   void onDrawerItemTapped(int index) {
//     selectedIndex.value = index; // Update selected index
//   }
//
//   void toggleDrawerCollapse() {
//     isCollapsed.value = !isCollapsed.value; // Toggle collapsed state
//   }
// }