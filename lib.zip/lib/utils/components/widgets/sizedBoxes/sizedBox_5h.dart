import 'package:flutter/material.dart';

class SizedBox5h extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 5,
    );
  }
}