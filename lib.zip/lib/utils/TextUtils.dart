// import 'package:flutter/material.dart';
//
// class AppBarUtils(){
// static appToCart(context, String message){
//   return Text(message,
//     style: TextStyle(
//       fontSize: 15.sp,
//       fontWeight: FontWeight.w500,
//       color: AppColors.primaryColor,
//     ),);
// }
//
//
// }
//
// class TextWithStyle(){
//
// }
//
//
//

