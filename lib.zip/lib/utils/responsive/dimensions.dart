const mobileWidth = 550;

const tabWidth = 1100;