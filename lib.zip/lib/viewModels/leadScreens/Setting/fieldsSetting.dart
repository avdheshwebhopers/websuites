import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import '../../../../Utils/utils.dart';
import '../../../../data/repositories/repositories.dart';
import '../../../data/models/responseModels/leads/setting/field_setting/field_setting.dart';

class FieldSettingController extends GetxController {
  final _api = Repositories();
  RxBool loading = false.obs;
  RxList<FieldSettingResponseModel> fieldsettings = <FieldSettingResponseModel>[].obs;

  Future<void> fieldSettingList(BuildContext context) async {
    loading.value = true;
    try {
      final value = await _api.fieldSetting();
      print("Field Setting Value: $value");
      if (value.isNotEmpty) {
        fieldsettings.value = FieldSettingResponseModel.fromJsonList(value);
        loading.value = false;
      } else {
        Utils.snackbarFailed('Field Setting not fetched');
        loading.value = false;
      }
    } catch (error) {
      if (kDebugMode) {
        print(error.toString());
      }
      Utils.snackbarFailed('Error fetching field settings');
      loading.value = false;
    }
  }
}
