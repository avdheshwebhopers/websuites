import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import '../../../../../Utils/utils.dart';
import '../../../../../data/repositories/repositories.dart';

class ProjectOverViewListViewModel extends GetxController{

  final _api = Repositories();
  RxBool loading = false.obs;
  Future<void> taskReportProjectOverview(BuildContext context) async {
    loading.value = true;
    _api.taskProjectOverview().then((response) {
      if (response.project?.id != null && response.project!.id!.isNotEmpty) {
        // Process each lead item
          print('Task Project OverView id ${response.project?.id}');
          print('Task Project OverView status  ${response.project?.status}');
          print('Task Project OverView status ${response.project!.members?[0].firstName}');
          print('Task Project OverView status task${response.tasks?.standard?.first.statusColor}');


        Utils.snackbarSuccess('Project OverView fetched successfully');
      }
      else{
        Utils.snackbarFailed('Project OverView not fetched');
      }
    }).onError((error, stackTrace) {
      if (kDebugMode) {
        print(error.toString());
      }
    }
    );
  }



}