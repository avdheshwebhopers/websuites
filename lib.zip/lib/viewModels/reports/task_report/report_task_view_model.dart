import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';

import '../../../Utils/utils.dart';
import '../../../data/repositories/repositories.dart';
class TaskReportViewModel extends GetxController{
  final _api = Repositories();
  RxBool loading = false.obs;
  Future<void> taskReport (BuildContext context) async {
    loading.value = true;
    ReportTaskRequestModel requestModel=ReportTaskRequestModel(date:"2024-12-03", limit:15, page:1, reportOf:null);
    _api.taskReport(requestModel.toJson()).then((response) {
      if (response.items.isNotEmpty) {
        // Process each lead item
        for (var data in response.items) {
          print('Task Report email  ${data.email}');
          print('Task Report User ${data.user}');
          print('Task Report User ${data.taskList}');

        }
        Utils.snackbarSuccess('Task Report fetched successfully');
      }
      else{
        Utils.snackbarFailed('Task Report not fetched');
      }
    }).onError((error, stackTrace) {
      if (kDebugMode) {
        print(error.toString());
      }
    }
    );
  }



}