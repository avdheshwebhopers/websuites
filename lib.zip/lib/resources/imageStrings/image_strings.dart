
class ImageStrings{

  // ===========================================================================

  static const String splashWHLogo = 'assets/images/WHLogo.png';

  static const String splashBottomLogo = 'assets/images/webhopers_logo1.png';

  static const String welcomeCompanyLogo = 'assets/images/welcome_company.png';

  static const String userImageDemo = 'assets/images/user_image_demo';

  static const String userAvatarDemo2 = 'assets/images/user_avatar_demo1';

  static const String userAvatarDemo3 = 'assets/images/user_demo_avtar.jpg';

  static const String worldMap = 'assets/images/World_Map.png';
  static const String dateCalender = 'assets/icons/date.png';
  static const String menuDot = 'assets/icons/Menuthreedot.png';




}