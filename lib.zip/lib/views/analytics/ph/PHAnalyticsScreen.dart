
import 'package:flutter/cupertino.dart';

class PHAnalyticsScreen extends StatefulWidget {
  const PHAnalyticsScreen({super.key});

  @override
  State<PHAnalyticsScreen> createState() => _PHAnalyticsScreenState();
}

class _PHAnalyticsScreenState extends State<PHAnalyticsScreen> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
