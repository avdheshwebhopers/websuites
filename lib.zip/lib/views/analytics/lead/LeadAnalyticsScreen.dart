
import 'package:flutter/cupertino.dart';

class LeadAnalyticsScreen extends StatefulWidget {
  const LeadAnalyticsScreen({super.key});

  @override
  State<LeadAnalyticsScreen> createState() => _LeadAnalyticsScreenState();
}

class _LeadAnalyticsScreenState extends State<LeadAnalyticsScreen> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
