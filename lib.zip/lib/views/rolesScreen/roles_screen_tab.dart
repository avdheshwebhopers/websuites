import 'package:flutter/material.dart';

class RolesScreenTab extends StatefulWidget {
  const RolesScreenTab({super.key});

  @override
  State<RolesScreenTab> createState() => _RolesScreenTabState();
}

class _RolesScreenTabState extends State<RolesScreenTab> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
