import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:websuites/utils/appColors/app_colors.dart';
import '../../../../../../resources/textStyles/text_styles.dart';
import '../../../../../../utils/MasterScreen/MasterUtils.dart';
import '../../../../../../viewModels/master/citiesStatesAndCountry/cities/master_cities_viewModel.dart';
import '../../../../viewModels/leadScreens/Setting/setting.dart';

class FieldSettingView extends StatefulWidget {
  const FieldSettingView({Key? key}) : super(key: key);

  @override
  _FieldSettingViewState createState() => _FieldSettingViewState();
}

class _FieldSettingViewState extends State<FieldSettingView> {
  final LeadSettingsViewModel _viewModel = Get.put(LeadSettingsViewModel());

  @override
  void initState() {
    super.initState();
    _viewModel.fetchLeadSettings(context);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLegend(),
        SizedBox(height: 16),
        Obx(() => _buildDataTable()),
      ],
    );
  }

  Widget _buildLegend() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLegendRow('S', AllColors.mediumPurple, 'Standard fields'),
        SizedBox(height: 8),
        _buildLegendRow('C', AllColors.mediumYellow, 'Custom fields'),
      ],
    );
  }

  Widget _buildLegendRow(String letter, Color color, String text) {
    return Row(
      children: [
        Image.asset('assets/icons/doticon.png', height: 10),
        SizedBox(width: 5),
        Container(
          alignment: Alignment.center,
          width: 18,
          height: 18,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(7),
          ),
          child: Text(
            letter,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
          ),
        ),
        Text(" - $text"),
      ],
    );
  }

  Widget _buildDataTable() {
    if (_viewModel.loading.value) {
      return Center(child: CircularProgressIndicator());
    }

    return MasterScreenUtils.buildDataTable(
      context: context,
      columns: const [
        DataColumn(label: Text('Column', style: TextStyles.masterScreen)),
        DataColumn(label: Text('Type', style: TextStyles.masterScreen)),
        DataColumn(label: Text('Is Required', style: TextStyles.masterScreen)),
        DataColumn(label: Text('Update Permission', style: TextStyles.masterScreen)),
      ],
      rows: _viewModel.settings.map((setting) {
        final isStandardField = setting.type == 'standard'; // Adjust based on your actual model

        return DataRow(cells: [
          DataCell(
            Row(
              children: [
                Container(
                  alignment: Alignment.center,
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    color: isStandardField ? AllColors.mediumYellow : AllColors.mediumPurple,
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child: Text(
                    isStandardField ? 'C' : 'S',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                ),
                SizedBox(width: 8),
                Text(setting.fieldName, style: TextStyles.namelength),
              ],
            ),
          ),
          DataCell(Text(setting.type ?? 'N/A', style: TextStyles.namelength)),
          DataCell(
            SizedBox(
              height: 16,
              child: Checkbox(
                value: setting.isVisible.value,
                onChanged: (value) {
                  setting.isVisible.value = value ?? false;
                },
                activeColor: AllColors.mediumPurple,
              ),
            ),
          ),
          DataCell(
            IconButton(
              icon: Image.asset('assets/icons/Edit.png', height: 20),
              onPressed: () {
                // Handle edit action
              },
            ),
          ),
        ]);
      }).toList(),
    );
  }
}