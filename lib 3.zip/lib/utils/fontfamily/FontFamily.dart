class FontFamily {
  static const String sfPro = 'SFPro'; // Font family name
}
