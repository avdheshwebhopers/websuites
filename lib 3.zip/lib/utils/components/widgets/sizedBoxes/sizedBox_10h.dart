import 'package:flutter/material.dart';

class SizedBox10h extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 10,
    );
  }
}