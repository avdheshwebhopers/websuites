import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import '../../../../../Utils/utils.dart';
import '../../../../../data/repositories/repositories.dart';
class TaskReportListViewModel extends GetxController{
  final _api = Repositories();
  RxBool loading = false.obs;
  Future<void> taskProjectReportList(BuildContext context) async {
    loading.value = true;
    var data={};
    _api.taskProjectReportList(data).then((response) {
      if(response.isNotEmpty){
        for (var responseData in response) {
          if (kDebugMode) {
            print("Task Report  List ${responseData.title}");
            print("Task Report  List List status ${responseData.project?.projectName}");
            print("Task Report  List List title ${responseData.title}");
            print("Task Report  List Create BY ${responseData.createdBy?.firstName}");
          }
          Utils.snackbarSuccess('Lead Detail Proposal data fetch');
        }
        loading.value = false;
      }
      else{
        Utils.snackbarFailed('Project OverView not fetched');
      }
    }).onError((error, stackTrace) {
      if (kDebugMode) {
        print(error.toString());
      }
    }
    );
  }


}