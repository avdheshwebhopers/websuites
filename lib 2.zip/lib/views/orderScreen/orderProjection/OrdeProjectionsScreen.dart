import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class OrderProjectionScreen extends StatefulWidget {
  const OrderProjectionScreen({super.key});

  @override
  State<OrderProjectionScreen> createState() => _OrderProjectionScreenState();
}

class _OrderProjectionScreenState extends State<OrderProjectionScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      backgroundColor: Colors.white,
      body: Text("hello vivek"),
    )
    ;
  }
}
