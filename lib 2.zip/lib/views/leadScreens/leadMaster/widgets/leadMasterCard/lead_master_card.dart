import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../resources/strings/strings.dart';
import '../../../../../resources/textStyles/text_styles.dart';
import '../../../../../utils/appColors/app_colors.dart';

class LeadMasterScreenCard extends StatelessWidget {
  final String title;
  final String activity;
  final String date;
  final List<String> subtypes;

  const LeadMasterScreenCard({
    Key? key,
    required this.title,
    required this.activity,
    required this.date,
    required this.subtypes,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: Get.height / 5.5,
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AllColors.whiteColor,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: AllColors.blackColor.withOpacity(0.06),
            spreadRadius: 2,
            blurRadius: 4,
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: Get.width < 600 ? 13 : 16,  // Responsive font size
                    color: AllColors.blackColor,
                  ),
                  overflow: TextOverflow.ellipsis,  // Ensure long text doesn't overflow
                ),
              ),
              const SizedBox(width: 10),
              Container(
                height: Get.height / 46,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: AllColors.lightPurple,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Center(
                  child: Text(
                    activity,
                    style: TextStyle(
                      color: AllColors.vividPurple,
                      fontSize: Get.width < 600 ? 12 : 14, // Responsive font size
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.calendar_month_outlined,
                  size: 16, color: AllColors.vividPurple),
              const SizedBox(width: 5),
              Text(
                date,
                style: TextStyle(
                  color: AllColors.grey,
                  fontWeight: FontWeight.w400,
                  fontSize: Get.width < 600 ? 12 : 14,  // Responsive font size
                ),
              ),
            ],
          ),
          const Divider(thickness: 0.2),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextStyles.w500_universal(
                  fontSize: Get.width < 600 ? 13 : 16,
                  color: AllColors.blackColor,
                  context,
                  Strings.subtypes),
              const SizedBox(width: 5),
              Icon(Icons.arrow_right_alt,
                  size: 18, color: AllColors.lightGrey),
              const SizedBox(width: 5),
              Expanded(
                child: Wrap(
                  spacing: 8,  // Space between chips
                  runSpacing: 8,  // Space between rows of chips
                  children: _buildSubtypes(),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<Widget> _buildSubtypes() {
    List<Widget> chips = [];

    if (subtypes.isEmpty) {
      chips.add(
        Text(
          'No subtypes available',
          style: TextStyle(
            color: AllColors.grey,
            fontSize: Get.width < 600 ? 12 : 14,  // Responsive font size
          ),
        ),
      );
      return chips;
    }

    for (String subtype in subtypes) {
      chips.add(_buildChip(subtype));
    }

    return chips;
  }

  Widget _buildChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      height: Get.height / 40,
      decoration: BoxDecoration(
        color: AllColors.textField2,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min, // Ensures the chip takes up just enough space
        children: [
          Text(
            label,
            style: TextStyle(
              color: AllColors.darkGrey,
              fontWeight: FontWeight.w400,
              fontSize: Get.width < 600 ? 12 : 14,  // Responsive font size
            ),
          ),
          const SizedBox(width: 5),
          Icon(
            Icons.edit,
            size: 14,
            color: AllColors.lightGrey,
          ),
        ],
      ),
    );
  }
}
