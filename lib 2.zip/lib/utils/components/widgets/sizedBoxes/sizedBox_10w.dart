import 'package:flutter/material.dart';

class SizedBox10w extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 10,
    );
  }
}