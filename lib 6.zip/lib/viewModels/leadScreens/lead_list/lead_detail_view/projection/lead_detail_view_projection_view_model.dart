import 'package:get/get.dart';

class LeadDetailViewProjectionViewModel extends GetxController{







}