import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AnalyticsTaskReportScreen extends StatefulWidget {
  const AnalyticsTaskReportScreen({super.key});

  @override
  State<AnalyticsTaskReportScreen> createState() => _AnalyticsTaskReportScreenState();
}

class _AnalyticsTaskReportScreenState extends State<AnalyticsTaskReportScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      Center(child: Text("analytics ")),

    );
  }
}
