<<<<<<< HEAD
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import '../../../../data/repositories/repositories.dart';
// import '../../../../utils/utils.dart';
// class CompanyCredentialsViewModels extends GetxController {
//   final _api = Repositories();
//   RxBool loading = false.obs;
//
//   Future<void> companyCredentialsType(BuildContext context) async {
//     loading.value = true;
//     _api.customerMasterCompanyCredential().then((value) {
//       if (value.isNotEmpty) {
//         for (var responseData in value) {
//           if (kDebugMode) {
//             print("Customer Company Credential name ${responseData.name}");
//             print("Customer Company Credential  ${responseData.createdAt}");
//           }
//           Utils.snackbarSuccess('Customer Company Credential List fetch');
//         }
//         loading.value = false;
//       }
//       else {
//         Utils.snackbarFailed('Customer Company Credential  not fetched');
//       }
//     }).onError((error, stackTrace) {
//       if (kDebugMode) {
//         print(error.toString());
//       }
//     }
//     );
//   }
// }
=======
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../Utils/utils.dart';
import '../../../../../data/repositories/repositories.dart';

class CompanyCredentialsViewModels extends GetxController {
  final _api = Repositories();
  RxBool loading = false.obs;

  Future<void> companyCredentials (BuildContext context) async {
    loading.value = true;

    _api.companyCredentialsApi().then((value) {

      if(value.id!= null){
        Utils.snackbarSuccess('company credentials fetched');
        loading.value = false;

      }else{
        Utils.snackbarFailed('company credentials id not fetched');
      }
    }).onError((error, stackTrace) {
      if (kDebugMode) {
        print(error.toString());
      }
    }
    );
  }
}
>>>>>>> origin/main
