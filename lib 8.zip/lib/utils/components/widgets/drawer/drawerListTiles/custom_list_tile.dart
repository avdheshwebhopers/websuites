import 'package:flutter/material.dart';

import '../../../../appColors/app_colors.dart';
import 'expandedListTile.dart';


class CustomListTile extends StatelessWidget {
  final String leadIconImage;
  final String title;
  final Function() onTap;
  final bool isCollapsed;

  const CustomListTile({
    Key? key,
    required this.leadIconImage,
    required this.title,
    required this.onTap,
    this.isCollapsed = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bool isSelected = SelectedMenuItems.selectedChild == title; // Check if this tile is selected

    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.symmetric(horizontal: 15.0),
      leading: Image.asset(leadIconImage),
      title: isCollapsed
          ? null
          : Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w300,
          color: isSelected || title == 'Dashboard' && SelectedMenuItems.selectedChild == null
              ? AllColors.mediumPurple // Highlight "Dashboard" if selected index is 0
              : AllColors.welcomeColor,
        ),
      ),
      onTap: () {
        SelectedMenuItems.selectedChild = title; // Update selected child
        onTap(); // Call the onTap function
      },
    );
  }
}

class CustomListTileTab extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const CustomListTileTab({
    Key? key,
    required this.icon,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return
      ListTile(
        dense: true,
        contentPadding: EdgeInsets.symmetric(horizontal: 15.0),
        leading: Icon(icon, size: 20, color: AllColors.lightGrey,),
        title: Text(title,
            style: TextStyle(
                fontSize: 16,

                fontWeight: FontWeight.w300,
                color: AllColors.blackColor)),
        onTap: onTap,

      );
  }
}



