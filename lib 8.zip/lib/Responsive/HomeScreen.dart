import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:websuites/views/customerScreens/companiesScreen/all_companies_screen.dart';
import 'package:websuites/views/customerScreens/customerList/list_screen.dart';
import 'package:websuites/views/leadScreens/Setting/SettingScreen.dart';
import 'package:websuites/views/leadScreens/leadActivities/lead_activities_screen.dart';
import 'package:websuites/views/leadScreens/leadList/leadlist_screen.dart';
import 'package:websuites/views/leadScreens/leadMaster/lead_master_screen.dart';

import '../Utils/Routes/routes_name.dart';
import '../resources/iconStrings/icon_strings.dart';
import '../special.dart';
import '../utils/appColors/app_colors.dart';
import '../utils/components/widgets/drawer/drawerListTiles/custom_list_tile.dart';
import '../utils/components/widgets/drawer/drawerListTiles/expandedListTile.dart';
import '../views/leadScreens/createNewLead/create_newLead_screen.dart';
import '../views/Dashboard/DashboardScreen.dart';
import '../views/leadScreens/searchGoogleLeads/search_google_leads.dart';
import '../views/leadScreens/trashLead/trash_lead_screen.dart';
import 'Custom_Drawer.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;
  bool isCollapsed = false;

  // final List<String> _titles = ['', 'Create', 'Lead','Customer List','Customer Companies'];
  final List<Widget> _screens = [
    Dashboardscreen(),
    CreateNewLeadScreen(),
    SearchGoogleLeads(),
    LeadListScreen(),
    LeadActivitiesScreen(),
    TrashLeadScreen(),
    SettingScreen(),
    LeadMasterScreen(),
    CustomersListScreen(),
    CustomerCompaniesScreen()

  ];

  void onDrawerItemTapped(int index) {
    setState(() {
      selectedIndex = index;
      // SelectedMenuItems.selectedChild = _titles[index]; // Update selected child
    });

    // Close the drawer on mobile screens
    if (MediaQuery.of(context).size.width < 500) {
      Navigator.pop(context);
    }
  }


  void toggleDrawerCollapse() {
    setState(() {
      isCollapsed = !isCollapsed;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isTabletOrDesktop = MediaQuery.of(context).size.width >= 500;
    // final title = _titles[selectedIndex];

    return Scaffold(
      // appBar: isTabletOrDesktop ? null : AppBar(
      //   backgroundColor: Colors.white,
      //   iconTheme: const IconThemeData(color: Colors.black),
      //   title: Text(
      //     title,
      //     style: const TextStyle(color: Colors.black, fontSize: 18),
      //   ),
      // ),
      drawer: !isTabletOrDesktop
          ? Drawer(
        child: CustomDrawer(
          selectedIndex: selectedIndex,
          onItemSelected: onDrawerItemTapped,
          isCollapsed: isCollapsed,
          onCollapseToggle: toggleDrawerCollapse,
          isTabletOrDesktop: isTabletOrDesktop,
        ),
      )
          : null,
      body: Row(
        children: [
          if (isTabletOrDesktop)
            CustomDrawer(
              selectedIndex: selectedIndex,
              onItemSelected: onDrawerItemTapped,
              isCollapsed: isCollapsed,
              onCollapseToggle: toggleDrawerCollapse,
              isTabletOrDesktop: isTabletOrDesktop,
            ),
          Expanded(
            child: Container(
              color: Colors.grey[100],
              child: Column(
                children: [
                  if (isTabletOrDesktop)
                    // Padding(
                    //   padding: const EdgeInsets.all(16.0),
                    //   child: Text(
                    //     title,
                    //     style: const TextStyle(
                    //       fontSize: 24,
                    //       fontWeight: FontWeight.bold,
                    //     ),
                    //   ),
                    // ),
                  Expanded(
                    child: IndexedStack(
                      index: selectedIndex,
                      children: _screens,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
