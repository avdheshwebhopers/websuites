import 'package:flutter/material.dart';
// class DashboardScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Text(
//         'dash  Content',
//         style: TextStyle(fontSize: 24),
//       ),
//     );
//   }
// }

class Inbox extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Inbox Content',
        style: TextStyle(fontSize: 24),
      ),
    );
  }
}

class Sent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Sent Content',
        style: TextStyle(fontSize: 24),
      ),
    );
  }
}

class Drafts extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Drafts Content',
        style: TextStyle(fontSize: 24),
      ),
    );
  }
}
