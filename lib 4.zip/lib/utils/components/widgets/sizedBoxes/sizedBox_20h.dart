import 'package:flutter/material.dart';

class SizedBox20h extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 20,
    );
  }
}