// import 'package:flutter/material.dart';
// import 'custom drawer.dart';
//
// class MainScreen extends StatefulWidget {
//   @override
//   _MainScreenState createState() => _MainScreenState();
// }
//
// class _MainScreenState extends State<MainScreen> {
//   int selectedIndex = 0;
//   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
//
//   final List<List<String>> emails = [
//     List.generate(20, (index) => 'Inbox Email ${index + 1}'),
//     List.generate(20, (index) => 'Sent Email ${index + 1}'),
//     List.generate(20, (index) => 'Draft Email ${index + 1}'),
//   ];
//
//   void onDrawerItemTapped(int index, BuildContext context) {
//     setState(() {
//       selectedIndex = index;
//     });
//     // Close drawer only on mobile
//     if (MediaQuery.of(context).size.width < 600) {
//       Navigator.pop(context);
//     }
//   }
//
//   Widget getScreenContent() {
//     return MailList(
//       title: ['Inbox', 'Sent', 'Drafts'][selectedIndex],
//       emails: emails[selectedIndex],
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     bool isTabletOrDesktop = MediaQuery.of(context).size.width >= 600;
//
//     return Scaffold(
//       key: _scaffoldKey,
//       appBar: AppBar(
//         leading: isTabletOrDesktop
//             ? null
//             : IconButton(
//                 icon: Icon(Icons.menu),
//                 onPressed: () {
//                   _scaffoldKey.currentState?.openDrawer();
//                 },
//               ),
//         title: Text('Gmail Clone'),
//         actions: [
//           IconButton(
//             icon: Icon(Icons.search),
//             onPressed: () {},
//           ),
//           IconButton(
//             icon: Icon(Icons.more_vert),
//             onPressed: () {},
//           ),
//         ],
//       ),
//       drawer: isTabletOrDesktop
//           ? null
//           : CustomDrawer(
//               selectedIndex: selectedIndex,
//               onItemSelected: (index) => onDrawerItemTapped(index, context),
//             ),
//       body: Row(
//         children: [
//           if (isTabletOrDesktop)
//             CustomDrawer(
//               selectedIndex: selectedIndex,
//               onItemSelected: (index) => onDrawerItemTapped(index, context),
//             ),
//           Expanded(
//             child: getScreenContent(),
//           ),
//         ],
//       ),
//     );
//   }
// }
//
// class MailList extends StatelessWidget {
//   final String title;
//   final List<String> emails;
//
//   const MailList({Key? key, required this.title, required this.emails})
//       : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: Colors.grey[100],
//       child: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: Text(
//               title,
//               style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//             ),
//           ),
//           Expanded(
//             child: ListView.builder(
//               itemCount: emails.length,
//               itemBuilder: (context, index) {
//                 return Card(
//                   margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                   child: ListTile(
//                     leading: CircleAvatar(
//                       child: Text('${index + 1}'),
//                     ),
//                     title: Text(emails[index]),
//                     subtitle: Text('Email preview text goes here...'),
//                     trailing: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.end,
//                       children: [
//                         Text('${DateTime.now().hour}:${DateTime.now().minute}'),
//                         Icon(Icons.star_border, size: 20),
//                       ],
//                     ),
//                   ),
//                 );
//               },
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
