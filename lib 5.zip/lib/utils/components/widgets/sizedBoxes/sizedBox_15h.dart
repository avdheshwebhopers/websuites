import 'package:flutter/material.dart';

class SizedBox15h extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 15,
    );
  }
}
