import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../appColors/app_colors.dart';

class CustomButton extends StatefulWidget {
  final double borderRadius; // Parameter for border radius
  final String text; // Parameter for button text
  final double fontSize; // Parameter for font size
  final FontWeight fontWeight; // Parameter for font weight

  const CustomButton({
    Key? key,
    this.borderRadius = 8.0, // Default value for border radius
    required this.text, // Make text required
    this.fontSize = 14.0, // Default font size
    this.fontWeight = FontWeight.w700, // Default font weight
  }) : super(key: key);

  @override
  State<CustomButton> createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: ElevatedButton(
        onPressed: () {
          // Your onPressed logic here
        },
        child: Text(
          widget.text, // Use the passed text
          style: TextStyle(
            fontSize: widget.fontSize, // Use the passed font size
            fontWeight: widget.fontWeight, // Use the passed font weight
          ),
        ),
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all(AllColors.mediumPurple), // Set background color
          foregroundColor: MaterialStateProperty.all(Colors.white), // Set text color
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(widget.borderRadius), // Use the passed border radius
            ),
          ),
        ),
      ),
    );
  }
}