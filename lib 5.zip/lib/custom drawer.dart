import 'package:flutter/material.dart';

class CustomDrawer extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onItemSelected;
  final bool isCollapsed;
  final VoidCallback? onCollapseToggle;
  final bool isTabletOrDesktop;

  const CustomDrawer({
    Key? key,
    required this.selectedIndex,
    required this.onItemSelected,
    required this.isTabletOrDesktop,
    this.isCollapsed = false,
    this.onCollapseToggle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final navigationItems = [
      NavigationItem(icon: Icons.inbox, label: 'Inbox', count: 24),
      NavigationItem(icon: Icons.send, label: 'Sent'),
      NavigationItem(icon: Icons.drafts, label: 'Drafts', count: 3),
    ];

    return Container(
      width: isCollapsed ? 80 : 280,
      color: Colors.white,
      child: Column(
        children: [
          // Header with logo, title, and collapse button
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 8.0, vertical: 16.0),
            child:
            Row(
              children: [
                ClipOval(
                  child: Image.network(
                    'https://webhopers.whsuites.com/public/logo/Webhopers%20%20(8)-6bc4.png',
                    width: 40,
                    height: 40,
                    fit: BoxFit.cover,
                  ),
                ),
                // Show the title only if the drawer is not collapsed
                if (!isCollapsed)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        'Webhopers',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                // Show the green toggle icon only on tablet and desktop

                if (isTabletOrDesktop)
                
                  Container(
                    width: 40, // Set a fixed width for the icon button to avoid overflow
                    child: IconButton(
                      icon: Icon(Icons.arrow_back_ios, color: Colors.green),
                      onPressed: onCollapseToggle,
                    ),
                  ),
              ],
            ),

          ),
          // List of navigation items
          Expanded(
            child: ListView.builder(
              itemCount: navigationItems.length,
              itemBuilder: (context, index) {
                final item = navigationItems[index];
                return ListTile(
                  leading: Icon(item.icon),
                  title: isCollapsed ? null : Text(item.label),
                  trailing: item.count != null
                      ? Container(
                          padding: EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: selectedIndex == index
                                ? Colors.blue[100]
                                : Colors.grey[300],
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '${item.count}',
                            style: TextStyle(fontSize: 12),
                          ),
                        )
                      : null,
                  selected: selectedIndex == index,
                  selectedTileColor: Colors.blue[50],
                  onTap: () {
                    onItemSelected(index);
                    if (!isTabletOrDesktop) {
                      Navigator.pop(context); // Close the drawer on mobile
                    }
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class NavigationItem {
  final IconData icon;
  final String label;
  final int? count;

  NavigationItem({
    required this.icon,
    required this.label,
    this.count,
  });
}
